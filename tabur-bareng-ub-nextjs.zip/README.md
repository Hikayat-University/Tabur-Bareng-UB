# Tabur Bareng UB — Web Platform

Platform ekosistem pembelajaran Tadabbur Al-Qur'an bersama Ustadz Budi Ashari.

## Stack
- **Next.js 14** (App Router)
- **TypeScript**
- **Tailwind CSS**
- **Supabase** (Auth + Storage) — Phase 2
- **Midtrans/Xendit** (Payment) — Phase 2
- **Vercel** (Hosting)

## Struktur Folder

```
src/
├── app/
│   ├── layout.tsx        # Root layout + metadata
│   ├── page.tsx          # Homepage
│   └── globals.css       # Global styles + font imports
└── components/
    ├── ui/
    │   └── Navbar.tsx    # Fixed navbar dengan mobile menu
    └── sections/
        ├── HeroSection.tsx      # Hero — identity + verse card
        ├── PremissSection.tsx   # Premiss + 3 steps
        └── OtherSections.tsx    # Stats, Event, Gallery,
                                 # Membership, FAQ, CTA, Footer
```

## Design System

| Token | Value |
|-------|-------|
| Navy Deepest | `#0D1B6E` |
| Navy Base | `#1a2e95` |
| Navy Light | `#2438B8` |
| Navy Footer | `#091040` |
| Lime | `#39FF14` |
| Font Display | Great Vibes / ITC Edwardian Script |
| Font Heading | Anton |
| Font Body | Poppins 300–500 |

## Setup di CodeSandbox

1. Buka [codesandbox.io](https://codesandbox.io)
2. New Sandbox → **Next.js** template
3. Replace semua file dengan file-file dari project ini
4. Otomatis running di preview

## Setup Lokal (untuk Developer)

```bash
git clone <repo-url>
cd tabur-bareng-ub
npm install
npm run dev
```

Buka `http://localhost:3000`

## Roadmap

### Phase 1 (Current)
- [x] Landing Page / Homepage
- [ ] Authentication (Supabase)
- [ ] Event Registration
- [ ] Membership + Payment

### Phase 2
- [ ] Learning Platform
- [ ] Reflection / Tadabbur Platform
- [ ] Certificates
- [ ] Leaderboard

### Phase 3
- [ ] Community Integration
- [ ] Admin Panel
- [ ] Ustadz Panel
- [ ] Analytics Dashboard
- [ ] Mobile Optimization
