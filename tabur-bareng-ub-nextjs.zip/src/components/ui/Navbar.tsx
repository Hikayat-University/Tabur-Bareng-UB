"use client";
import { useState, useEffect } from "react";

const navLinks = [
  { label: "Event", href: "#event" },
  { label: "Tentang", href: "#tentang" },
  { label: "Membership", href: "#membership" },
  { label: "Galeri", href: "#galeri" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
      style={{
        background: "rgba(9, 16, 64, 0.88)",
        backdropFilter: "blur(14px)",
        borderBottom: scrolled
          ? "1px solid rgba(57,255,20,0.18)"
          : "1px solid rgba(57,255,20,0.06)",
      }}
    >
      <div className="max-w-[1280px] mx-auto px-6 md:px-10 h-[72px] flex items-center justify-between">

        {/* Logo */}
        <a href="/" className="flex flex-col leading-none">
          <span className="font-display text-lime-DEFAULT text-xl leading-tight">
            Tabur
          </span>
          <span className="font-heading text-white text-sm tracking-widest uppercase leading-tight">
            Bareng UB
          </span>
        </a>

        {/* Desktop nav */}
        <ul className="hidden md:flex items-center gap-8">
          {navLinks.map((l) => (
            <li key={l.label}>
              <a
                href={l.href}
                className="font-heading text-xs tracking-[0.18em] uppercase text-white/60 hover:text-lime-DEFAULT transition-colors"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        {/* CTA */}
        <a
          href="#event"
          className="hidden md:inline-block font-heading text-xs tracking-[0.12em] uppercase px-6 py-3 rounded-lg transition-all duration-200 hover:-translate-y-0.5"
          style={{ background: "#39FF14", color: "#0D1B6E" }}
        >
          Daftar Sekarang
        </a>

        {/* Mobile hamburger */}
        <button
          className="md:hidden text-white p-2"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
        >
          <div className="w-6 flex flex-col gap-1.5">
            <span className={`block h-0.5 bg-lime-DEFAULT transition-all ${menuOpen ? "rotate-45 translate-y-2" : ""}`} />
            <span className={`block h-0.5 bg-white transition-all ${menuOpen ? "opacity-0" : ""}`} />
            <span className={`block h-0.5 bg-white transition-all ${menuOpen ? "-rotate-45 -translate-y-2" : ""}`} />
          </div>
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div
          className="md:hidden px-6 pb-6 flex flex-col gap-4"
          style={{ background: "rgba(9,16,64,0.97)" }}
        >
          {navLinks.map((l) => (
            <a
              key={l.label}
              href={l.href}
              onClick={() => setMenuOpen(false)}
              className="font-heading text-sm tracking-widest uppercase text-white/70 hover:text-lime-DEFAULT transition-colors py-2 border-b border-white/10"
            >
              {l.label}
            </a>
          ))}
          <a
            href="#event"
            className="font-heading text-sm tracking-widest uppercase text-center py-3 rounded-lg mt-2"
            style={{ background: "#39FF14", color: "#0D1B6E" }}
          >
            Daftar Sekarang
          </a>
        </div>
      )}
    </nav>
  );
}
